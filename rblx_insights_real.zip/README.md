# RBLX Insights — real Roblox public stats

A responsive, installable-feeling web app prototype that queries Roblox public APIs. It does not show fabricated fallback numbers.

## Run locally

1. Install Node.js 18 or newer.
2. Extract this folder.
3. Open a terminal in this folder and run:

   ```bash
   npm start
   ```

4. Open http://localhost:3000 in your browser.

No npm dependencies are required. The server uses Node's built-in `fetch`.

## Included

- Search Roblox experiences by name or numeric universe ID
- Public experience data: concurrent players, visits, favorites, creator, description, dates, max players
- Public upvote/downvote ratio when Roblox returns vote data
- Responsive mobile layout and bottom navigation
- Local watchlist saved in the browser
- Refresh button for a fresh public API snapshot
- Clear handling for unavailable data, API errors, and rate limits

## Real-data limitations

- Public player count is a snapshot, not a historical time series.
- Roblox may omit fields, throttle requests, or change API behavior.
- Creator-only metrics such as revenue, retention, and detailed analytics require access to Roblox Creator analytics/Open Cloud permissions for that experience.
- To create a historical chart, a deployed backend must periodically save player-count snapshots to a database. This starter intentionally does not draw fake historical charts.
- Do not put Roblox API keys in frontend code. If you add authorized Open Cloud analytics, keep secrets on the server and request only permissions you need.

## Deployment

Deploy to a Node.js host that supports Node 18+. The web server serves the UI and proxies the public API requests. The app is a web app; for phone home-screen installation, a production deployment should add a web manifest and service worker.
